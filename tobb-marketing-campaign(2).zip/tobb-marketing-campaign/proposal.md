# Marketing Proposal: Your Business. Better Connected.

**Tobb Technologies – Business Growth & Marketing Challenge**  
**Prepared by:** Lulu Mash  
**Programme:** Richfield Higher Certificate in IT  
**Date:** 30 October 2026

## 1. Summary

This proposal recommends a small digital marketing pilot for Tobb Technologies called **“Your Business. Better Connected.”** The campaign is designed to encourage small-business owners and operational decision-makers to contact the company about web application requirements or improvements to an existing system.

The practical deliverable is a promotional graphic, supported by three social media captions and a prospective-client email template. The campaign focuses on explaining the potential business value of software and web application development in clear language and providing a direct way to enquire.

This is a proposed campaign prototype. It has not been published, approved by the company or tested with customers. The proposed enquiry targets in this document are targets for a future pilot, not achieved results.

## 2. Company information and evidence boundaries

Tobb Technologies is the organisation for which this marketing concept has been prepared. The company website supplied for this assignment is https://tobb.io. The contact details supplied for the assignment are:

- Address: 7 Gold Reef Road, Ormonde, Johannesburg South
- Telephone: +27 73 182 0631
- Email: admin@tobb.io
- Additional email: besi@tobb.io

The campaign is written around web application development and related software and database services, as specified in the assignment brief. The exact service list, wording, company logo, brand colours and preferred enquiry channel should be confirmed by an authorised company representative before publication. The dark navy and teal colours used in the prototype are design suggestions, not verified company branding.

No customer testimonials, client names, project outcomes, prices or performance guarantees have been added. The campaign does not claim that Tobb Technologies has achieved any particular business result.

## 3. Your WIL observations

During my WIL placement, I worked with other students on the software reengineering of an existing web application called Zonke, using Laravel. I explored routes, controllers and application functionality while learning how an existing application is structured and how changes need to fit into the current system.

I also participated in computer hardware testing and troubleshooting. This included inspecting system units and keyboards and using component substitution to investigate hardware faults.

These experiences helped me understand that technology projects should begin with a clear understanding of a user's or organisation's problem. They also showed me the importance of testing, communication, consistency and explaining technical work in a way that makes sense to people who will use the solution. I used these observations to shape a marketing message that starts with a business need rather than technical jargon.

## 4. Marketing opportunity

A potential customer may know that an existing process is inefficient or that their organisation needs a web application, but may not know what to ask a technology provider. A concise campaign can help explain the type of discussion a prospective client can start with Tobb Technologies.

The opportunity is to:
- Make the company's proposed web application and software services easier to understand.
- Reach small-business owners and operational decision-makers in the Johannesburg area.
- Encourage a relevant enquiry through the company's approved contact channels.
- Provide consistent material that can be reused and measured.

This opportunity is a proposal for testing. It is not a claim that the company currently lacks marketing activity or that a verified market gap has been established.

## 5. Target audience

The proposed initial audience is small-business owners and operational decision-makers in Johannesburg who:
- Are considering a new web application.
- Need to improve or extend an existing web-based system.
- Want to discuss software that supports a business process.
- Need to understand what information to prepare before speaking to a technology provider.

This is a proposed audience hypothesis, not a validated customer segment. Tobb Technologies should review whether it matches the company's actual services, capacity and preferred customers.

## 6. Proposed solution

The campaign title is **“Your Business. Better Connected.”** The main message is:

> Need a web application—or want to improve an existing one? Talk to Tobb Technologies about your next digital project.

The practical marketing deliverables are:

### 6.1 Promotional graphic

The square promotional graphic uses the company name as text rather than an unverified logo. It presents the campaign headline, the three service areas specified for this assignment, and the supplied contact details. It uses dark navy, white and teal as suggested colours. The graphic is saved as `marketing-assets/promotional-graphic.png`.

### 6.2 Social media captions

Three draft captions support the graphic and give the campaign a simple sequence:
1. Introduce the service and the business need.
2. Explain why a web application should be considered in relation to business requirements.
3. Invite interested people to start a conversation.

The captions are saved in `marketing-assets/social-captions.md`.

### 6.3 Prospective-client email

A short email template is included in `marketing-assets/outreach-email.md`. It is intended for an authorised company representative to review and personalise. It has not been sent. Recipient and sender details must be completed by an authorised person, and outreach must follow the company's policies and applicable privacy requirements.

## 7. Research-based justification

Digital channels can help organisations communicate with potential customers and make information about their services accessible. Chaffey and Ellis-Chadwick (2022) explain how digital marketing uses online channels and measurable interactions to support marketing objectives. This supports using social media content and a clear enquiry route as a low-cost pilot that can be reviewed using engagement and enquiry data.

The campaign also uses a customer-oriented message. Kotler, Keller and Chernev (2022) describe marketing as creating, communicating and delivering value to a chosen market. For this reason, the graphic begins with a practical customer question and invites a discussion about requirements, instead of making unsupported promises about technical outcomes.

These sources support the general marketing approach. They do not prove that this particular campaign will generate customers. Its effectiveness would need to be tested using actual campaign data.

## 8. Implementation

The campaign can be implemented in five steps:

1. **Company review:** Ask an authorised representative to confirm the service descriptions, contact details, logo, brand colours and approved channels.
2. **Final design:** Apply approved branding and export the graphic in the correct dimensions for the selected social platforms.
3. **Content schedule:** If approved, publish the three captions over approximately two weeks. For example, publish the first post in week one, the second later that week, and the third in week two.
4. **Enquiry handling:** Direct interested people to the approved website or contact channel. An authorised staff member should respond and record the enquiry appropriately.
5. **Evaluation:** Review reach, engagement, website visits where analytics are available, relevant enquiries and follow-up outcomes after 30 days.

The schedule is a suggested pilot plan. Actual publication dates and channels depend on company approval and available resources.

## 9. Resources and responsibilities

| Resource or responsibility | Proposed owner |
|---|---|
| Confirm services, logo, colours and contact details | Tobb Technologies representative |
| Review and approve campaign wording | Tobb Technologies representative |
| Prepare the draft graphic and captions | Student campaign creator |
| Approve social media channels and publication | Authorised company representative |
| Respond to prospective-client enquiries | Tobb Technologies |
| Record and review campaign results | Assigned company representative |

The initial organic pilot can use the supplied graphic and captions without a paid advertising budget. If paid promotion is considered later, the company should approve a budget before any spending.

## 10. Expected benefits

If the company approves and uses the campaign, potential benefits include:
- A consistent message about the service areas being promoted.
- Reusable social media content.
- A clearer call to action for prospective customers.
- A simple process for recording and reviewing enquiries.
- An opportunity to learn which messages attract relevant interest.

These are expected or potential benefits, not results already achieved.

## 11. Success measures

The following are proposed measures for a 30-day pilot:

| Measure | How it will be assessed | Proposed target |
|---|---|---|
| Post reach | Platform analytics showing unique accounts reached | Record a baseline and seek improvement across the pilot |
| Engagement | Comments, shares and saves | Compare performance across the three posts |
| Website interest | Link clicks or website visits, if analytics are available | Track visits attributed to the campaign where possible |
| Relevant enquiries | Enquiries that relate to the promoted services | Aim for at least 3 relevant enquiries during the pilot |
| Follow-up progress | Enquiries that proceed to a discussion or next step | Record outcomes; review quality, not only quantity |

The target of at least three relevant enquiries is a suggested pilot goal, not a forecast or achieved result. The company should adjust it to its audience size, channels and capacity. Likes alone should not be treated as evidence of business growth.

## 12. Risks and limitations

- **Unverified service wording:** The promoted services must be confirmed by the company before publication.
- **Unverified branding:** The logo and colours must be checked. The current graphic uses a text-only company name and suggested colours.
- **Audience uncertainty:** The proposed audience has not been validated through customer research.
- **Limited measurement:** Results can only be evaluated if the company has access to relevant platform and website analytics and records enquiries consistently.
- **Privacy and consent:** The company should use approved contact lists and follow its privacy and communication policies. The student email template must not be sent without company approval.
- **No guaranteed results:** A social media campaign cannot guarantee enquiries or sales. The pilot should be reviewed and adjusted based on evidence.

## 13. References

Chaffey, D. and Ellis-Chadwick, F. (2022) *Digital Marketing*. 8th edn. Harlow: Pearson.

Kotler, P., Keller, K.L. and Chernev, A. (2022) *Marketing Management*. 16th edn. Harlow: Pearson.

Tobb Technologies (n.d.) *Tobb Technologies website*. Available at: https://tobb.io (Accessed: 30 October 2026).

## Source and verification note

The WIL observations in this proposal are based on my own placement activities. The company contact details were supplied for this assignment. The website and all company-facing campaign wording should be checked by Tobb Technologies before public use. The academic references support the general marketing principles discussed; they are not evidence of Tobb Technologies' internal performance or customer demand.
