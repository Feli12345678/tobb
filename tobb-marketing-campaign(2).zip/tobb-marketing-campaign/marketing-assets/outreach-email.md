# Prospective-Client Email Template

Status: Draft for company review.  
This template has not been sent.  
Recipient and sender details must be completed by an authorised person.

**Subject:** Discussing your web application requirements

Dear [Prospective Client Name],

I hope you are well.

I am contacting you on behalf of Tobb Technologies to introduce our web application and software-related services.

If your organisation is considering a new web application or improvements to an existing system, we would welcome the opportunity to understand your requirements and discuss the possible next steps.

If this is something your organisation is exploring, please let us know a suitable time for an initial conversation. You can also find more information at https://tobb.io.

Kind regards,

[Authorised Sender Name]  
[Job Title]  
Tobb Technologies  
Telephone: +27 73 182 0631  
Email: admin@tobb.io

---
**Internal use note:** This is a proposed template only. An authorised Tobb Technologies representative must review and approve it, complete the recipient and sender details, and ensure that the recipient may lawfully be contacted before sending.
