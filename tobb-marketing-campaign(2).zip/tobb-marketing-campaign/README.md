# Tobb Technologies Marketing Campaign

## Campaign title
Your Business. Better Connected.

## Student information
Name: Lulu Mash
Programme: Richfield Higher Certificate in IT
Date: 30 October 2026

## Project overview
This project proposes a digital marketing campaign for Tobb Technologies,
focusing on web application development and related software and
database services.

The campaign includes a promotional graphic, three social media
captions, and a prospective-client email template.

## Purpose
To encourage prospective clients to contact Tobb Technologies
and discuss their web application requirements.

## Proposed target audience
Small-business owners and operational decision-makers in Johannesburg
who are considering a new web application or improvements to an
existing system.

This is a proposed audience for testing, not a validated customer segment.

## Connection to my WIL experience
During my WIL placement, I worked with other students on the software
reengineering of an existing web application called Zonke, using Laravel.

I explored routes, controllers, and application functionality.
I also participated in computer hardware testing and troubleshooting.

These experiences informed my decision to create a campaign focused
on web application development and improvement.

## Potential business value
The campaign provides reusable promotional material, a focused service
message, and clear contact details for prospective clients.

The intended benefit is to generate relevant enquiries.
No actual campaign results are claimed.

## Repository contents
- proposal.md: Referenced campaign proposal.
- marketing-assets/: Promotional graphic, captions, and email template.
- evidence/: Screenshots demonstrating the completed work.

## How Tobb could use this campaign
1. Review and approve the wording and contact details.
2. Confirm branding and obtain the verified company logo.
3. Approve suitable publication channels.
4. Publish the approved campaign materials.
5. Record enquiries and evaluate the results.

## Company contact details
Address: 7 Gold Reef Road, Ormonde, Johannesburg South
Telephone: +27 73 182 0631
Email: admin@tobb.io
Additional email: besi@tobb.io

## Project status
This campaign is a prototype prepared for the assignment.
It requires company approval before public publication or outreach.

Company details were supplied for this assignment.
The original company logo still requires verification.
