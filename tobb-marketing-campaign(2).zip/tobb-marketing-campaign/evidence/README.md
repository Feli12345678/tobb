# Evidence folder

Add only screenshots that you personally capture.

Suggested evidence:
- `promotional-graphic-screenshot.png` — screenshot of the finished graphic opened in your editor or image viewer.
- `github-repository-screenshot.png` — screenshot of the uploaded GitHub repository showing the project files.

These screenshots are not included yet because they must show your actual work and your actual GitHub repository. Do not create substitute or mock screenshots.
